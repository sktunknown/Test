package testing;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class yt {
    private static WebDriver driver;
    private static final String path = "C:\\Users\\sanjay kumar T\\Downloads\\chromedriver.exe";
    @Test
    public void test1_driver()
    {
        System.setProperty("webdriver.chrome.driver",path);
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
    }
    @Test
    public void test2_website()
    {
        driver.get("http://www.youtube.com/");
    }
    @Test
    public void test3_signin_click()
    {
        driver.findElement(By.xpath("//tp-yt-paper-button[@aria-label = 'Sign in']")).click();
    }
    @Test
    public void test4_username()
    {
        driver.findElement(By.xpath("//input[@class = 'whsOnd zHQkBf'][@autocomplete='username']")).sendKeys("test2021.selenium@gmail.com");
        driver.findElement(By.cssSelector("button[class = 'VfPpkd-LgbsSe VfPpkd-LgbsSe-OWXEXe-k8QpJ VfPpkd-LgbsSe-OWXEXe-dgl2Hf nCP5yc AjY5Oe DuMIQc qIypjc TrZEUc lw1w4b']")).click();
    }
    @Test
    public void test5_password() throws InterruptedException
    {
        driver.findElement(By.xpath("//input[@class = 'whsOnd zHQkBf'][@name='password']")).sendKeys("selenium2021");
        //driver.findElement(By.cssSelector("//div[@class='VfPpkd-Jh9lGc']")).click();
        Thread.sleep(2000);
        driver.findElement(By.cssSelector("button[class = 'VfPpkd-LgbsSe VfPpkd-LgbsSe-OWXEXe-k8QpJ VfPpkd-LgbsSe-OWXEXe-dgl2Hf nCP5yc AjY5Oe DuMIQc qIypjc TrZEUc lw1w4b']")).click();
    }
}
