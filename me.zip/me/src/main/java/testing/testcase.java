package testing;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class testcase {

    private static WebDriver driver;
    private static final String path = "C:\\Users\\sanjay kumar T\\Downloads\\chromedriver.exe";
    private static final Func ob = new Func();

    @Test
    public void test1driver()
    {
        driver = ob.initiate(path);
    }
    @Test
    public void test2website()
    {
        String website = "https://www.youtube.com/";
        ob.gpage(website, driver);
    }
    @Test
    public void test3title()
    {
        String title = ob.gettitle(driver);
        System.out.println(title);
        Assert.assertEquals("YouTube",title);

    }
    @Test
    public void test4close()
    {
        ob.closedriver(driver);
    }

}
