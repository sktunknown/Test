package testing;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class Swithtabs {
    private static WebDriver driver;
    private static final String path = "C:\\Users\\sanjay kumar T\\Downloads\\chromedriver.exe";
    private String previous =null,current=null;

    @Test

    public void test1_driver()
    {
        System.setProperty("webdriver.chrome.driver",path);
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }
    @Test
    public void test2_tab1()
    {
        driver.get("https://www.youtube.com/");
        current = driver.getWindowHandle();

    }
    @Test
    public void test3_newtab() throws AWTException
    {
        Robot r = new Robot();
        r.keyPress(KeyEvent.VK_CONTROL);
        r.keyPress(KeyEvent.VK_T);
        r.keyRelease(KeyEvent.VK_CONTROL);
        r.keyRelease(KeyEvent.VK_T);
    }
    @Test
    public void test4_tab2()
    {
        ArrayList<String> newTab = new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(newTab.get(1));
        previous = current;
        driver.get("https://www.amazon.com/");
        current = driver.getWindowHandle();
    }
    @Test
    public void test5_prevTab()
    {
        driver.switchTo().window(previous);
        previous = current;
        current = driver.getWindowHandle();
        driver.navigate().to("https://www.youtube.com/channel/UCkw4JCwteGrDHIsyIIKo4tQ");
        driver.navigate().back();
    }

}
